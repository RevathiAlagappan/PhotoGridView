//
//  ImagesListVC.swift
//  TaskSolulab
//
//  Created by Kishore on 25/08/21.
//

import UIKit
import Alamofire
import SDWebImage

var arrData = [DataModel]()
var selectedItem = Int()

class ImagesListVC: UIViewController {
    
    //MARK:- IBOutlets
    @IBOutlet weak var listClVw: UICollectionView!
    
    //MARK:- View life cycle

    override func viewDidLoad() {
        super.viewDidLoad()
        
        calApi()
    }
    
    //MARK:- Additional functions

    func calApi(){
        if Connectivity.isConnectedToInternet() {
            toastMessage("Yes! internet is available.")
            showActivityIndicator()
            
            AF.request("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&count=42", method: .get).responseJSON{ response in
                if let data = response.data {
                    do {
                        let res = try  JSONDecoder().decode(Array<DataModel>.self, from: data)
                        arrData.append(contentsOf: res)
                        self.listClVw.reloadData()
                    } catch {
                        print(error.localizedDescription)
                        print("JSON Serialization error ")
                    }
                }
                self.hideActivityIndicator()
            }
        } else {
            toastMessage(" Please check InternetConnectivity ")
        }
    }
    
    func toastMessage(_ message: String){
        guard let window = UIApplication.shared.keyWindow else {return}
        let messageLbl = UILabel()
        messageLbl.text = message
        messageLbl.textAlignment = .center
        messageLbl.font = UIFont.systemFont(ofSize: 12)
        messageLbl.textColor = .white
        messageLbl.backgroundColor = UIColor(white: 0, alpha: 0.5)
        
        let textSize:CGSize = messageLbl.intrinsicContentSize
        let labelWidth = min(textSize.width, window.frame.width - 40)
        
        messageLbl.frame = CGRect(x: 20, y: window.frame.height - 90, width: labelWidth + 30, height: textSize.height + 20)
        messageLbl.center.x = window.center.x
        messageLbl.layer.cornerRadius = messageLbl.frame.height/2
        messageLbl.layer.masksToBounds = true
        window.addSubview(messageLbl)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            
            UIView.animate(withDuration: 2, animations: {
                messageLbl.alpha = 0
            }) { (_) in
                messageLbl.removeFromSuperview()
            }
        }
    }
}

//MARK:- UICollectionViewDelegate And UICollectionViewDataSource

extension ImagesListVC: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = self.listClVw.dequeueReusableCell(withReuseIdentifier: "ImagesCollectionViewCell", for: indexPath) as! ImagesCollectionViewCell
        
        cell.img.sd_setImage(with: URL(string: arrData[indexPath.row].url ?? "https://apod.nasa.gov/apod/image/magellan_sc.gif"))
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: (self.listClVw.frame.width)/3 - 2, height: 120)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedItem = indexPath.item
        print("self.selectedItem --> \(selectedItem)")
        
        let nextVC = self.storyboard?.instantiateViewController(identifier: "popUpVC") as! popUpVC
        nextVC.modalPresentationStyle = .fullScreen
        self.navigationController?.present(nextVC, animated: true, completion: nil)
    }
    
}

