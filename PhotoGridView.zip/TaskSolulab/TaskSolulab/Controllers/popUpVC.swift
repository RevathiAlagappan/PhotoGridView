//
//  popUpVC.swift
//  TaskSolulab
//
//  Created by Kishore on 26/08/21.
//

import UIKit

class popUpVC: UIViewController {

    //MARK:- IBOutlets
    @IBOutlet weak var imgPreView: UIImageView!
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(self.getSwipeAction(_:)))
        let swipeGesture2 = UISwipeGestureRecognizer(target: self, action: #selector(self.getSwipeAction(_:)))
        
        swipeGesture.direction = .right
        swipeGesture2.direction = .left
        
        self.imgPreView.addGestureRecognizer(swipeGesture)
        self.imgPreView.addGestureRecognizer(swipeGesture2)        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        upDateImage()
    }
    
    //MARK:- IBActions

    @IBAction func dismissPopUpAction(_ sender: UIButton) {
            self.dismiss(animated: true, completion: nil)
    }
    
    //MARK:- Additional functions

    @objc func getSwipeAction( _ recognizer : UISwipeGestureRecognizer){
        if recognizer.direction == .right{
            if selectedItem != 0 {
                selectedItem -= 1
            }
        } else if recognizer.direction == .left {
            if selectedItem != arrData.count-1 {
                selectedItem += 1
            }
        }
        upDateImage()
    }

    func upDateImage() {
        imgPreView.sd_setImage(with: URL(string: arrData[selectedItem].url ?? ""))
    }
}
