//
//  DateModel.swift
//  TaskSolulab
//
//  Created by Kishore on 26/08/21.
//

import Foundation

struct DataModel : Decodable{
    let date, explanation: String?
    let hdurl: String?
    let mediaType, serviceVersion, title: String?
    let url: String?
    let copyright: String?
}
