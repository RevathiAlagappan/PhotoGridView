//
//  ImagesCollectionViewCell.swift
//  TaskSolulab
//
//  Created by Kishore on 25/08/21.
//

import UIKit

class ImagesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var img: UIImageView!
}
